#!/bin/bash

#checkout project source code
svn checkout --username ${JENKINS_USER} --password ${JENKINS_PASSWORD} svn://svn.mb.bluecross.ca/${SOURCE_PROJECT}/${SOURCE_BRANCH} .

#export IMAGE_TAG for tagging Docker images, which are created during application build process and published to ECR
if [[ $SOURCE_BRANCH != 'trunk' ]]
then
  SOURCE_BRANCH="${SOURCE_BRANCH#branches/}"
fi

SVN_REVISION=`svn info |grep Revision: |cut -c11-`
export IMAGE_TAG=$SOURCE_BRANCH.$SVN_REVISION

#build project
chmod +x ./gradlew && chmod +x *.sh
./build.sh